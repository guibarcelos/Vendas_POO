﻿
namespace Vendas
{
    partial class frmVendas
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVendas));
            this.lblNomeProdut = new System.Windows.Forms.Label();
            this.lblQuantidade = new System.Windows.Forms.Label();
            this.lblprecoUnitario = new System.Windows.Forms.Label();
            this.txtNomeProduto = new System.Windows.Forms.TextBox();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.txtPrecoUnitario = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblValorCompra = new System.Windows.Forms.Label();
            this.lblDesconto = new System.Windows.Forms.Label();
            this.lbltotalAPagar = new System.Windows.Forms.Label();
            this.txtValorDaCompra = new System.Windows.Forms.TextBox();
            this.txtValorDoDesconto = new System.Windows.Forms.TextBox();
            this.lblValorAPagar = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNomeProdut
            // 
            this.lblNomeProdut.AutoSize = true;
            this.lblNomeProdut.Location = new System.Drawing.Point(8, 9);
            this.lblNomeProdut.Name = "lblNomeProdut";
            this.lblNomeProdut.Size = new System.Drawing.Size(93, 13);
            this.lblNomeProdut.TabIndex = 0;
            this.lblNomeProdut.Text = "Nome do Produto:";
            // 
            // lblQuantidade
            // 
            this.lblQuantidade.AutoSize = true;
            this.lblQuantidade.Location = new System.Drawing.Point(8, 48);
            this.lblQuantidade.Name = "lblQuantidade";
            this.lblQuantidade.Size = new System.Drawing.Size(65, 13);
            this.lblQuantidade.TabIndex = 1;
            this.lblQuantidade.Text = "Quantidade:";
            this.lblQuantidade.Click += new System.EventHandler(this.lblQuantidade_Click);
            // 
            // lblprecoUnitario
            // 
            this.lblprecoUnitario.AutoSize = true;
            this.lblprecoUnitario.Location = new System.Drawing.Point(8, 88);
            this.lblprecoUnitario.Name = "lblprecoUnitario";
            this.lblprecoUnitario.Size = new System.Drawing.Size(77, 13);
            this.lblprecoUnitario.TabIndex = 2;
            this.lblprecoUnitario.Text = "Preço Unitário:";
            // 
            // txtNomeProduto
            // 
            this.txtNomeProduto.Location = new System.Drawing.Point(117, 6);
            this.txtNomeProduto.Name = "txtNomeProduto";
            this.txtNomeProduto.Size = new System.Drawing.Size(221, 20);
            this.txtNomeProduto.TabIndex = 3;
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Location = new System.Drawing.Point(117, 45);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(112, 20);
            this.txtQuantidade.TabIndex = 4;
            this.txtQuantidade.TextChanged += new System.EventHandler(this.txtQuantidade_TextChanged);
            // 
            // txtPrecoUnitario
            // 
            this.txtPrecoUnitario.Location = new System.Drawing.Point(117, 81);
            this.txtPrecoUnitario.Name = "txtPrecoUnitario";
            this.txtPrecoUnitario.Size = new System.Drawing.Size(112, 20);
            this.txtPrecoUnitario.TabIndex = 5;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.Red;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.ForeColor = System.Drawing.Color.White;
            this.btnCalcular.Location = new System.Drawing.Point(10, 107);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(219, 41);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(232, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(105, 115);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // lblValorCompra
            // 
            this.lblValorCompra.AutoSize = true;
            this.lblValorCompra.Location = new System.Drawing.Point(12, 169);
            this.lblValorCompra.Name = "lblValorCompra";
            this.lblValorCompra.Size = new System.Drawing.Size(88, 13);
            this.lblValorCompra.TabIndex = 8;
            this.lblValorCompra.Text = "Valor da Compra:";
            // 
            // lblDesconto
            // 
            this.lblDesconto.AutoSize = true;
            this.lblDesconto.Location = new System.Drawing.Point(12, 209);
            this.lblDesconto.Name = "lblDesconto";
            this.lblDesconto.Size = new System.Drawing.Size(56, 13);
            this.lblDesconto.TabIndex = 9;
            this.lblDesconto.Text = "Desconto:";
            // 
            // lbltotalAPagar
            // 
            this.lbltotalAPagar.AutoSize = true;
            this.lbltotalAPagar.Location = new System.Drawing.Point(12, 246);
            this.lbltotalAPagar.Name = "lbltotalAPagar";
            this.lbltotalAPagar.Size = new System.Drawing.Size(74, 13);
            this.lbltotalAPagar.TabIndex = 10;
            this.lbltotalAPagar.Text = "Total a Pagar:";
            // 
            // txtValorDaCompra
            // 
            this.txtValorDaCompra.Enabled = false;
            this.txtValorDaCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorDaCompra.Location = new System.Drawing.Point(117, 169);
            this.txtValorDaCompra.Name = "txtValorDaCompra";
            this.txtValorDaCompra.Size = new System.Drawing.Size(219, 31);
            this.txtValorDaCompra.TabIndex = 11;
            this.txtValorDaCompra.Text = "0";
            this.txtValorDaCompra.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtValorDoDesconto
            // 
            this.txtValorDoDesconto.Enabled = false;
            this.txtValorDoDesconto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorDoDesconto.Location = new System.Drawing.Point(117, 206);
            this.txtValorDoDesconto.Name = "txtValorDoDesconto";
            this.txtValorDoDesconto.Size = new System.Drawing.Size(219, 31);
            this.txtValorDoDesconto.TabIndex = 12;
            this.txtValorDoDesconto.Text = "0";
            this.txtValorDoDesconto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblValorAPagar
            // 
            this.lblValorAPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorAPagar.Location = new System.Drawing.Point(117, 246);
            this.lblValorAPagar.Name = "lblValorAPagar";
            this.lblValorAPagar.Size = new System.Drawing.Size(219, 23);
            this.lblValorAPagar.TabIndex = 13;
            this.lblValorAPagar.Text = "0";
            this.lblValorAPagar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmVendas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 276);
            this.Controls.Add(this.lblValorAPagar);
            this.Controls.Add(this.txtValorDoDesconto);
            this.Controls.Add(this.txtValorDaCompra);
            this.Controls.Add(this.lbltotalAPagar);
            this.Controls.Add(this.lblDesconto);
            this.Controls.Add(this.lblValorCompra);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtPrecoUnitario);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.txtNomeProduto);
            this.Controls.Add(this.lblprecoUnitario);
            this.Controls.Add(this.lblQuantidade);
            this.Controls.Add(this.lblNomeProdut);
            this.Name = "frmVendas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Venda de Produtos";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeProdut;
        private System.Windows.Forms.Label lblQuantidade;
        private System.Windows.Forms.Label lblprecoUnitario;
        private System.Windows.Forms.TextBox txtNomeProduto;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.TextBox txtPrecoUnitario;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblValorCompra;
        private System.Windows.Forms.Label lblDesconto;
        private System.Windows.Forms.Label lbltotalAPagar;
        private System.Windows.Forms.TextBox txtValorDaCompra;
        private System.Windows.Forms.TextBox txtValorDoDesconto;
        private System.Windows.Forms.Label lblValorAPagar;
    }
}

