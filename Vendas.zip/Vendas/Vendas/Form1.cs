﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vendas
{
    public partial class frmVendas : Form
    {
        public frmVendas()
        {
            InitializeComponent();
        }

        private void txtQuantidade_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblQuantidade_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string nomeProduto;
            int quantidade;
            double precoUnitario, valorCompra, valorDesconto = 0, valorAPagar;

            //Entrada de Dados
            nomeProduto   = txtNomeProduto.Text;
            quantidade    = int.Parse(txtQuantidade.Text);
            precoUnitario = double.Parse(txtPrecoUnitario.Text);

            //processamento

            valorCompra = precoUnitario * quantidade;

            if (quantidade > 0 && quantidade <= 5)
            {
                valorDesconto = valorCompra * 0.02;     // 2% é o mesmo que 2/100 = 0.02
            }
            else if (quantidade >= 6 && quantidade <= 10)
            {
                valorDesconto = valorCompra * 0.03;     // 3% é o mesmo que 3/100 = 0.03
            }
            else if (quantidade > 10)
            {
                valorDesconto = valorCompra * 0.05;     // 5% é o mesmo que 5/100 = 0.05
            }
            else
            {
                MessageBox.Show("Quantidade fornecida é inválida.");
            }

            valorAPagar = valorCompra - valorDesconto;

            txtValorDaCompra.Text   = valorCompra.ToString("C");
            txtValorDoDesconto.Text = valorDesconto.ToString("C");
            lblValorAPagar.Text     = valorAPagar.ToString("C");
        }
    }
}
